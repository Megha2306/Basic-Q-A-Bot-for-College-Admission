from nltk.stem import WordNetLemmatizer
import torch
def preprocess_sentence(sentence, words):
    lemmatizer = WordNetLemmatizer()
    sentence_words = sentence.lower().split()
    sentence_words = [lemmatizer.lemmatize(word) for word in sentence_words]
    return sentence_words

def sentence_to_features(sentence_words, words):
    features = [1 if word in sentence_words else 0 for word in words]
    return torch.tensor(features).float().unsqueeze(0)
