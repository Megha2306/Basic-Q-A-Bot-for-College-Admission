from flask import Flask, render_template, request
import torch
import json
import random
from utils.model.py import NeuralNetwork, preprocess_sentence, vectorize_sentence

app = Flask(__name__)

# Load the trained model
model_path = 'utils.model.pth'
input_size = 20  # Define the input size according to your model
hidden_size = 8  # Define the hidden size according to your model
output_size = 3  # Define the number of classes according to your model
model = NeuralNetwork(input_size, hidden_size, output_size)
model.load_state_dict(torch.load(model_path))
model.eval()  # Set the model to evaluation mode

# Load the intents data
with open('intents.json', 'r') as f:
    intents = json.load(f)

# Load vocabulary or word index (if needed for vectorization)
with open('model/words.json', 'r') as f:
    words = json.load(f)
with open('model/classes.json', 'r') as f:
    classes = json.load(f)

def chatbot_response(user_input):
    # Preprocess the user input and vectorize it
    sentence_words = preprocess_sentence(user_input, words)
    if len(sentence_words) == 0:
        return "I'm sorry, but I don't understand. Can you please rephrase or provide more information?"

    features = vectorize_sentence(sentence_words, words)
    with torch.no_grad():
        outputs = model(torch.tensor(features, dtype=torch.float32).unsqueeze(0))
    
    probabilities, predicted_class = torch.max(outputs, dim=1)
    confidence = probabilities.item()
    predicted_tag = classes[predicted_class.item()]

    # Find the corresponding response
    if confidence > 0.5:
        for intent in intents['intents']:
            if intent['tag'] == predicted_tag:
                response = random.choice(intent['responses'])
                return response

    return "I'm sorry, but I'm not sure how to respond to that."

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/chat', methods=['POST'])
def chat():
    user_input = request.form['user_input']
    response = chatbot_response(user_input)
    return response

if __name__ == '__main__':
    app.run(debug=True)
